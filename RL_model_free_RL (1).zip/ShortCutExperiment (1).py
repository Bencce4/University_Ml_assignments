import os
import pandas as pd
import numpy as np
from tabulate import tabulate
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Arrow

from ShortCutAgents import QLearningAgent, SARSAAgent, ExpectedSARSAAgent, nStepSARSAAgent
from ShortCutEnvironment import ShortcutEnvironment, WindyShortcutEnvironment


def calculate_performance_metrics(rewards_by_alpha, alphas, window_size=20):
    metrics = []

    for rewards, alpha in zip(rewards_by_alpha, alphas):
        final_performance = np.mean(rewards[-window_size:])
        average_reward = np.mean(rewards)
        metrics.append({
            'Learning Rate (α)': alpha,
            'Final Performance': round(final_performance, 1),
            'Average Reward': round(average_reward, 1)
        })

    return pd.DataFrame(metrics)


def smooth_learning_curve(rewards, window_size=20):
    rewards = np.array(rewards)
    if rewards.ndim == 1:
        rewards = rewards.reshape(1, -1)

    smoothed = np.zeros_like(rewards, dtype=float)
    for i in range(rewards.shape[0]):
        for t in range(rewards.shape[1]):
            effective_window = min(window_size, t + 1)
            smoothed[i, t] = np.mean(rewards[i, max(0, t - effective_window + 1):t + 1])
    return smoothed[0] if smoothed.shape[0] == 1 else smoothed

def Q_initial_experiment():
    seed = 5000
    rng = np.random.default_rng(seed)
    env = ShortcutEnvironment(seed=seed)
    agent = QLearningAgent(
        n_actions=env.action_size(),
        n_states=env.state_size(),
        epsilon=0.1,
        alpha=0.1,
        rng=rng
    )
    agent.train(10000, env)
    env.render_greedy(agent.Q)


def Q_similar_experiment(n_rep, n_episodes):
    trial_rewards = []
    for i in range(n_rep):
        seed = 5000 + i
        rng = np.random.default_rng(seed)
        env = ShortcutEnvironment(seed=seed)
        agent = QLearningAgent(
            n_actions=env.action_size(),
            n_states=env.state_size(),
            epsilon=0.1,
            alpha=0.1,
            rng=rng
        )
        trial_rewards.append(agent.train(n_episodes, env))

    mean_rewards = np.mean(trial_rewards, axis=0)
    plt.plot(range(n_episodes), mean_rewards)
    plt.xlabel("Episodes")
    plt.ylabel("Cumulative Reward")
    plt.title("Q-Learning (mean over repetitions)")
    plt.show()
    plt.clf()

def Q_alpha_experiment(alphas, n_rep=100, n_episodes=1000, window_size=20):
    mean_rewards_by_alpha = []
    for alpha in alphas:
        print(f'Beginning experiment @ alpha {alpha}')
        trial_rewards = []
        for i in range(n_rep):
            seed = 42 + i
            rng = np.random.default_rng(seed)
            env = ShortcutEnvironment(seed=seed)
            agent = QLearningAgent(n_actions=env.action_size(), n_states=env.state_size(), epsilon=0.1, alpha=alpha, rng=rng)
            trial_rewards.append(agent.train(n_episodes, env))
        mean_rewards_by_alpha.append(np.mean(trial_rewards, axis=0))

    plt.figure(figsize=(6, 4))
    for i, alpha in enumerate(alphas):
        smoothed = smooth_learning_curve(mean_rewards_by_alpha[i], window_size)
        plt.plot(range(n_episodes), smoothed, label=f'alpha = {alpha}')
    plt.xlabel('Episodes')
    plt.ylabel('Cumulative Reward')
    plt.legend()
    plt.ylim([-1000, 0])
    plt.tight_layout()
    plt.savefig('q_alpha_experiment.png')

    metrics_df = calculate_performance_metrics(mean_rewards_by_alpha, alphas)
    print("\nPerformance Metrics:")
    print(tabulate(metrics_df, headers='keys', tablefmt='pipe', showindex=False))

    return mean_rewards_by_alpha, metrics_df

def SARSA_initial_experiment():
    seed = 6000
    rng = np.random.default_rng(seed)
    env = ShortcutEnvironment(seed=seed)
    agent = SARSAAgent(
        n_actions=env.action_size(),
        n_states=env.state_size(),
        epsilon=0.1,
        alpha=0.1,
        rng=rng
    )
    agent.train(10000, env)
    env.render_greedy(agent.Q)


def SARSA_similar_experiment(n_rep, n_episodes):
    trial_rewards = []
    for i in range(n_rep):
        seed = 6000 + i
        rng = np.random.default_rng(seed)
        env = ShortcutEnvironment(seed=seed)
        agent = SARSAAgent(
            n_actions=env.action_size(),
            n_states=env.state_size(),
            epsilon=0.1,
            alpha=0.1,
            rng=rng
        )
        trial_rewards.append(agent.train(n_episodes, env))

    mean_rewards = np.mean(trial_rewards, axis=0)
    plt.plot(range(n_episodes), mean_rewards)
    plt.xlabel("Episodes")
    plt.ylabel("Cumulative Reward")
    plt.title("SARSA (mean over repetitions)")
    plt.show()
    plt.clf()

def SARSA_alpha_experiment(alphas, n_rep=100, n_episodes=1000, window_size=20):
    mean_rewards_by_alpha = []
    for alpha in alphas:
        print(f'Beginning experiment @ alpha {alpha}')
        trial_rewards = []
        for i in range(n_rep):
            seed = 1000 + i
            rng = np.random.default_rng(seed)
            env = ShortcutEnvironment(seed=seed)
            agent = SARSAAgent(n_actions=env.action_size(), n_states=env.state_size(), epsilon=0.1, alpha=alpha, rng=rng)
            trial_rewards.append(agent.train(n_episodes, env))
        mean_rewards_by_alpha.append(np.mean(trial_rewards, axis=0))

    plt.figure(figsize=(6, 4))
    for i, alpha in enumerate(alphas):
        smoothed = smooth_learning_curve(mean_rewards_by_alpha[i], window_size)
        plt.plot(range(n_episodes), smoothed, label=f'alpha = {alpha}')
    plt.xlabel('Episodes')
    plt.ylabel('Cumulative Reward')
    plt.legend()
    plt.ylim([-1000, 0])
    plt.tight_layout()
    plt.savefig('sarsa_alpha_experiment.png')

    metrics_df = calculate_performance_metrics(mean_rewards_by_alpha, alphas)
    print("\nPerformance Metrics:")
    print(tabulate(metrics_df, headers='keys', tablefmt='pipe', showindex=False))

    return mean_rewards_by_alpha, metrics_df

def expected_SARSA_similar_experiment(n_rep, n_episodes):
    trial_rewards = []
    for i in range(n_rep):
        seed = 7000 + i
        rng = np.random.default_rng(seed)
        env = ShortcutEnvironment(seed=seed)
        agent = ExpectedSARSAAgent(
            n_actions=env.action_size(),
            n_states=env.state_size(),
            epsilon=0.1,
            alpha=0.1,
            rng=rng
        )
        trial_rewards.append(agent.train(n_episodes, env))

    mean_rewards = np.mean(trial_rewards, axis=0)
    plt.plot(range(n_episodes), mean_rewards)
    plt.xlabel("Episodes")
    plt.ylabel("Cumulative Reward")
    plt.title("Expected SARSA (mean over repetitions)")
    plt.show()
    plt.clf()

def expected_SARSA_alpha_experiment(alphas, n_rep=100, n_episodes=1000, window_size=20):
    mean_rewards_by_alpha = []
    for alpha in alphas:
        print(f'Beginning experiment @ alpha {alpha}')
        trial_rewards = []
        for i in range(n_rep):
            seed = 2000 + i
            rng = np.random.default_rng(seed)
            env = ShortcutEnvironment(seed=seed)
            agent = ExpectedSARSAAgent(n_actions=env.action_size(), n_states=env.state_size(), epsilon=0.1, alpha=alpha, rng=rng)
            trial_rewards.append(agent.train(n_episodes, env))
        mean_rewards_by_alpha.append(np.mean(trial_rewards, axis=0))

    plt.figure(figsize=(6, 4))
    for i, alpha in enumerate(alphas):
        smoothed = smooth_learning_curve(mean_rewards_by_alpha[i], window_size)
        plt.plot(range(n_episodes), smoothed, label=f'alpha = {alpha}')
    plt.xlabel('Episodes')
    plt.ylabel('Cumulative Reward')
    plt.legend()
    plt.ylim([-1000, 0])
    plt.tight_layout()
    plt.savefig('expected_sarsa_alpha_experiment.png')

    metrics_df = calculate_performance_metrics(mean_rewards_by_alpha, alphas)
    print("\nPerformance Metrics:")
    print(tabulate(metrics_df, headers='keys', tablefmt='pipe', showindex=False))

    return mean_rewards_by_alpha, metrics_df

def nstep_initial_experiment():
    seed = 8000
    rng = np.random.default_rng(seed)
    env = ShortcutEnvironment(seed=seed)
    agent = nStepSARSAAgent(
        n_actions=env.action_size(),
        n_states=env.state_size(),
        n=10,
        epsilon=0.1,
        alpha=0.1,
        rng=rng
    )
    agent.train(10000, env)
    env.render_greedy(agent.Q)

def nstep_SARSA_n_experiment(ns, n_rep=100, n_episodes=1000, window_size=20):
    mean_rewards_by_n = []
    for n in ns:
        print(f'Beginning experiment @ n = {n}')
        trial_rewards = []
        for i in range(n_rep):
            seed = 3000 + i
            rng = np.random.default_rng(seed)
            env = ShortcutEnvironment(seed=seed)
            agent = nStepSARSAAgent(n_actions=env.action_size(), n_states=env.state_size(), n=n, epsilon=0.1, alpha=0.1, rng=rng)
            trial_rewards.append(agent.train(n_episodes, env))
        mean_rewards_by_n.append(np.mean(trial_rewards, axis=0))

    plt.figure(figsize=(6, 4))
    for i, n in enumerate(ns):
        smoothed = smooth_learning_curve(mean_rewards_by_n[i], window_size)
        plt.plot(range(n_episodes), smoothed, label=f'n = {n}')
    plt.xlabel('Episodes')
    plt.ylabel('Cumulative Reward')
    plt.legend()
    plt.ylim([-1000, 0])
    plt.tight_layout()
    plt.savefig('nstep_sarsa_n_experiment.png')

    metrics_df = calculate_performance_metrics(mean_rewards_by_n, ns)
    metrics_df.rename(columns={"Learning Rate (α)": "n"}, inplace=True)
    print("\nPerformance Metrics:")
    print(tabulate(metrics_df, headers='keys', tablefmt='pipe', showindex=False))

    return mean_rewards_by_n, metrics_df

def plot_all_alpha_experiments_side_by_side(q_rewards, sarsa_rewards, expected_rewards, nstep_rewards,
                                             q_alphas, sarsa_alphas, expected_alphas, nstep_ns,
                                             window_size=20, n_episodes=1000):
    fig, axs = plt.subplots(1, 4, figsize=(20, 5))  # One row, four columns
    titles = ['Q-Learning', 'SARSA', 'Expected SARSA', 'n-step SARSA']
    all_rewards = [q_rewards, sarsa_rewards, expected_rewards, nstep_rewards]
    all_params = [q_alphas, sarsa_alphas, expected_alphas, nstep_ns]
    ylims = [(-1000, 0)] * 4  # consistent y-axis

    for i in range(4):
        for j, param in enumerate(all_params[i]):
            smoothed = smooth_learning_curve(all_rewards[i][j], window_size)
            label = f'α = {param}' if i < 3 else f'n = {param}'
            axs[i].plot(range(n_episodes), smoothed, label=label)

        axs[i].set_title(titles[i])
        axs[i].set_xlabel('Episodes')
        if i == 0:
            axs[i].set_ylabel('Cumulative Reward')  # show y-label only once for clarity
        axs[i].legend()
        axs[i].set_ylim(ylims[i])
        axs[i].grid(True)

    plt.tight_layout(rect=[0, 0, 1, 0.92])
    plt.savefig("all_td_learning_curves_horizontal.png")

def compare_algorithms(n_rep=100, n_episodes=1000, window_size=20):
    algorithms = [
        ("Q-Learning", QLearningAgent, {"alpha": 0.1, "epsilon": 0.1}),
        ("SARSA", SARSAAgent, {"alpha": 0.1, "epsilon": 0.1}),
        ("Expected SARSA", ExpectedSARSAAgent, {"alpha": 0.9, "epsilon": 0.1}),
        ("n-Step SARSA", nStepSARSAAgent, {"alpha": 0.1, "epsilon": 0.1, "n": 2}),
    ]

    all_mean_rewards = []

    for name, agent_class, params in algorithms:
        print(f'Running comparison for {name}')
        trial_rewards = []
        for i in range(n_rep):
            seed = 4000 + i
            rng = np.random.default_rng(seed)
            env = ShortcutEnvironment(seed=seed)

            if "n" in params:
                agent = agent_class(
                    n_actions=env.action_size(),
                    n_states=env.state_size(),
                    alpha=params["alpha"],
                    epsilon=params["epsilon"],
                    n=params["n"],
                    rng=rng
                )
            else:
                agent = agent_class(
                    n_actions=env.action_size(),
                    n_states=env.state_size(),
                    alpha=params["alpha"],
                    epsilon=params["epsilon"],
                    rng=rng
                )
            trial_rewards.append(agent.train(n_episodes, env))

        all_mean_rewards.append((name, np.mean(trial_rewards, axis=0)))

    plt.figure(figsize=(6, 4))
    for name, rewards in all_mean_rewards:
        smoothed = smooth_learning_curve(rewards, window_size)
        plt.plot(range(n_episodes), smoothed, label=name)
    plt.grid(True)
    plt.xlabel('Episodes')
    plt.ylabel('Cumulative Reward')
    plt.legend()
    plt.ylim([-1000, 0])
    plt.tight_layout()
    plt.savefig('algorithm_comparison.png')

class PlotEnvironment:
    def __init__(self, env, agent, render_size=0.33):
        self.env = env
        self.agent = agent
        self.render_size = render_size
        self.action_effects = {
                0: (0, 1),  # up
                1: (0, -1),   # down
                2: (-1, 0),   # left
                3: (1, 0),  # right
                }

        self.height = env.r
        self.width = env.c
        self.grid = env.s[:, :-1][::-1]
        self.grid[9, 2] = 'S'
        self.grid[2, 2] = 'S'
        self.Q = agent.Q[::-1]

    def create_grid(self, hide_arrows=False, save_fig=None, dpi=600):
        self.fig, self.ax = plt.subplots(figsize=(self.width * self.render_size, self.height * self.render_size))
        self.ax.set_xlim([0, self.width])
        self.ax.set_ylim([0, self.height])
        self.ax.axes.xaxis.set_visible(False)
        self.ax.axes.yaxis.set_visible(False)

        # Draw grid lines to ensure all borders are visible
        for x in range(self.width + 1):
            self.ax.axvline(x=x, color='black', linestyle='-', linewidth=0.5)
        for y in range(self.height + 1):
            self.ax.axhline(y=y, color='black', linestyle='-', linewidth=0.5)

        # Draw the colored cells
        for x in range(self.width):
            for y in range(self.height):
                if self.grid[y, x] == 'X':
                    self.ax.add_patch(Rectangle((x + 0.02, y + 0.02), 0.96, 0.96, linewidth=0, facecolor='w'))
                if self.grid[y, x] == 'S':
                    self.ax.add_patch(Rectangle((x, y), 1, 1, linewidth=0, facecolor='b', alpha=0.2))
                    self.ax.add_patch(Rectangle((x, y), 1, 1, linewidth=1.5, edgecolor='b', fill=False))
                if self.grid[y, x] == 'C':
                    self.ax.add_patch(Rectangle((x, y), 1, 1, linewidth=0, facecolor='r', alpha=0.2))
                    self.ax.add_patch(Rectangle((x, y), 1, 1, linewidth=1.5, edgecolor='r', fill=False))
                if self.grid[y, x] == 'G':
                    self.ax.add_patch(Rectangle((x, y), 1, 1, linewidth=0, facecolor='g', alpha=0.2))
                    self.ax.add_patch(Rectangle((x, y), 1, 1, linewidth=1.5, edgecolor='g', fill=False))

        if not hide_arrows:
            self.add_arrows()

        if save_fig:
            script_dir = os.path.dirname(os.path.abspath(__file__))
            save_path = os.path.join(script_dir, save_fig)
            plt.savefig(save_path, dpi=dpi, bbox_inches='tight')
            print(f"Saved figure to: {save_path}")
    
    def add_arrows(self):
        for state in range(self.Q.shape[0]):
            row = state // self.width
            col = state - (row * self.height)
            max_action = np.argmax(self.Q[state])
            if self.grid[row, 11-col] in ['C', 'G']:
                continue
            new_arrow = Arrow(11.5-col,row+0.5,self.action_effects[max_action][0]*0.33,
                                        self.action_effects[max_action][1]*0.33, width=0.05,color='k')
            self.ax.add_patch(new_arrow)

env = WindyShortcutEnvironment()
agent = SARSAAgent(n_actions=env.action_size(), n_states=env.state_size(), epsilon=0.1, alpha=0.1)
agent.train(10000, env)
a = PlotEnvironment(env, agent)
a.create_grid(save_fig="SARSA_windy")


env = WindyShortcutEnvironment()
agent = QLearningAgent(n_actions=env.action_size(), n_states=env.state_size(), epsilon=0.1, alpha=0.1)
agent.train(10000, env)
a = PlotEnvironment(env, agent)
a.create_grid(save_fig="Q_learning_windy")

env = ShortcutEnvironment()
agent = QLearningAgent(n_actions=env.action_size(), n_states=env.state_size(), epsilon=0.1, alpha=0.1)
agent.train(10000, env)
a = PlotEnvironment(env, agent)
a.create_grid(save_fig="Q_learning_normal")

env = ShortcutEnvironment()
agent = SARSAAgent(n_actions=env.action_size(), n_states=env.state_size(), epsilon=0.1, alpha=0.1)
agent.train(10000, env)
a = PlotEnvironment(env, agent)
a.create_grid(save_fig="SARSA_normal")

env = ShortcutEnvironment()
agent = ExpectedSARSAAgent(n_actions=env.action_size(), n_states=env.state_size(), epsilon=0.1, alpha=0.9)
agent.train(10000, env)
a = PlotEnvironment(env, agent)
a.create_grid(save_fig="expected_SARSA_normal")

q_rewards, _ = Q_alpha_experiment([0.01, 0.1, 0.5, 0.9])
sarsa_rewards, _ = SARSA_alpha_experiment([0.01, 0.1, 0.5, 0.9])
expected_rewards, _ = expected_SARSA_alpha_experiment([0.01, 0.1, 0.5, 0.9])
nstep_rewards, _ = nstep_SARSA_n_experiment([1, 2, 5, 10, 25])

plot_all_alpha_experiments_side_by_side(
    q_rewards, sarsa_rewards, expected_rewards, nstep_rewards,
    [0.01, 0.1, 0.5, 0.9],
    [0.01, 0.1, 0.5, 0.9],
    [0.01, 0.1, 0.5, 0.9],
    [1, 2, 5, 10, 25]
)

compare_algorithms()
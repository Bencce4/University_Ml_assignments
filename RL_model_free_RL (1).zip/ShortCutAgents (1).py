import numpy as np

class QLearningAgent(object):
    def __init__(self, n_actions, n_states, epsilon=0.1, alpha=0.1, gamma=1.0, rng=None):
        self.n_actions = n_actions
        self.n_states = n_states
        self.epsilon = epsilon
        self.alpha = alpha
        self.gamma = gamma
        self.Q = np.zeros((n_states, n_actions))
        self.rng = rng if rng is not None else np.random.default_rng()

    def select_action(self, state):
        if self.rng.random() < self.epsilon:
            return self.rng.integers(self.n_actions)
        return np.argmax(self.Q[state])

    def update(self, state, next_state, action, reward):
        self.Q[state, action] += self.alpha * (reward + self.gamma * np.max(self.Q[next_state]) - self.Q[state, action])

    def train(self, n_episodes, env):
        episode_returns = []
        for _ in range(n_episodes):
            cum_reward = 0
            while not env.done():
                state = env.state()
                action = self.select_action(state)
                reward = env.step(action)
                cum_reward += reward
                next_state = env.state()
                self.update(state, next_state, action, reward)
            env.reset()
            episode_returns.append(cum_reward)
        return episode_returns


class SARSAAgent(object):
    def __init__(self, n_actions, n_states, epsilon=0.1, alpha=0.1, gamma=1.0, rng=None):
        self.n_actions = n_actions
        self.n_states = n_states
        self.epsilon = epsilon
        self.alpha = alpha
        self.gamma = gamma
        self.Q = np.zeros((n_states, n_actions))
        self.rng = rng if rng is not None else np.random.default_rng()

    def select_action(self, state):
        if self.rng.random() < self.epsilon:
            return self.rng.integers(self.n_actions)
        return np.argmax(self.Q[state])

    def update(self, state, next_state, action, next_action, reward):
        self.Q[state, action] += self.alpha * (reward + self.gamma * self.Q[next_state, next_action] - self.Q[state, action])

    def train(self, n_episodes, env):
        episode_returns = []
        for _ in range(n_episodes):
            cum_reward = 0
            state = env.state()
            action = self.select_action(state)
            while not env.done():
                reward = env.step(action)
                next_state = env.state()
                next_action = self.select_action(next_state)
                cum_reward += reward
                self.update(state, next_state, action, next_action, reward)
                state, action = next_state, next_action
            env.reset()
            episode_returns.append(cum_reward)
        return episode_returns


class ExpectedSARSAAgent(object):
    def __init__(self, n_actions, n_states, epsilon=0.1, alpha=0.1, gamma=1.0, rng=None):
        self.n_actions = n_actions
        self.n_states = n_states
        self.epsilon = epsilon
        self.alpha = alpha
        self.gamma = gamma
        self.Q = np.zeros((n_states, n_actions))
        self.rng = rng if rng is not None else np.random.default_rng()

    def select_action(self, state):
        if self.rng.random() < self.epsilon:
            return self.rng.integers(self.n_actions)
        return np.argmax(self.Q[state])

    def update(self, state, action, reward, next_state):
        policy = np.full(self.n_actions, self.epsilon / self.n_actions)
        best_action = np.argmax(self.Q[next_state])
        policy[best_action] += (1 - self.epsilon)
        expected_value = np.dot(self.Q[next_state], policy)
        self.Q[state, action] += self.alpha * (reward + self.gamma * expected_value - self.Q[state, action])

    def train(self, n_episodes, env):
        episode_returns = []
        for _ in range(n_episodes):
            cum_reward = 0
            state = env.state()
            while not env.done():
                action = self.select_action(state)
                reward = env.step(action)
                next_state = env.state()
                cum_reward += reward
                self.update(state, action, reward, next_state)
                state = next_state
            env.reset()
            episode_returns.append(cum_reward)
        return episode_returns


class nStepSARSAAgent(object):
    def __init__(self, n_actions, n_states, n, epsilon=0.1, alpha=0.1, gamma=1.0, rng=None):
        self.n_actions = n_actions
        self.n_states = n_states
        self.n = n
        self.epsilon = epsilon
        self.alpha = alpha
        self.gamma = gamma
        self.Q = np.zeros((n_states, n_actions))
        self.rng = rng if rng is not None else np.random.default_rng()

    def select_action(self, state):
        if self.rng.random() < self.epsilon:
            return self.rng.integers(self.n_actions)
        return np.argmax(self.Q[state])

    def update(self, states, actions, rewards):
        s, a = states[0], actions[0]
        G = sum(self.gamma**i * r for i, r in enumerate(rewards))
        if len(states) > len(rewards):
            G += (self.gamma ** len(rewards)) * self.Q[states[-1], actions[-1]]
        self.Q[s, a] += self.alpha * (G - self.Q[s, a])

    def train(self, n_episodes, env):
        episode_returns = []
        for _ in range(n_episodes):
            cum_reward = 0
            states, actions, rewards = [], [], []
            state = env.state()
            action = self.select_action(state)
            states.append(state)
            actions.append(action)

            while not env.done():
                reward = env.step(action)
                next_state = env.state()
                next_action = self.select_action(next_state)
                cum_reward += reward
                rewards.append(reward)
                states.append(next_state)
                actions.append(next_action)

                if len(rewards) >= self.n:
                    self.update(states, actions, rewards)
                    states.pop(0)
                    actions.pop(0)
                    rewards.pop(0)

                state, action = next_state, next_action

            while rewards:
                self.update(states, actions, rewards)
                states.pop(0)
                actions.pop(0)
                rewards.pop(0)

            env.reset()
            episode_returns.append(cum_reward)
        return episode_returns

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Model-based Reinforcement Learning experiments
Practical for course 'Reinforcement Learning',
Bachelor AI, Leiden University, The Netherlands
By Thomas Moerland
"""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from tabulate import tabulate
import time

from MBRLEnvironment import WindyGridworld
from MBRLAgents import DynaAgent, PrioritizedSweepingAgent
from Helper import LearningCurvePlot, smooth

def summarize_mbrl_performance(reward_curves, method_labels, window_size=2):
    """
    Summarizes average and final rewards for MBRL experiments (including Q-learning baseline).

    Parameters:
        reward_curves: list of 1D np.arrays (mean reward curves)
        method_labels: list of strings describing each method (e.g., "DynaQ (n=3)", "Q-learning")
        window_size: int, how many final points to average for final performance

    Returns:
        pd.DataFrame with formatted performance metrics
    """
    metrics = []
    for rewards, label in zip(reward_curves, method_labels):
        final_performance = np.mean(rewards[-window_size:])
        average_reward = np.mean(rewards)
        metrics.append({
            'Agent': label,
            'Final Reward': round(final_performance, 1),
            'Average Reward': round(average_reward, 1)
        })
    df = pd.DataFrame(metrics)
    print("\nPerformance Metrics:")
    print(tabulate(df, headers='keys', tablefmt='pipe', showindex=False))
    return df

def plot_learning_curves(stochastic_curves, deterministic_curves, filename='dual_plot.png'):
    """
    Plots two side-by-side learning curves: stochastic (left) and deterministic (right).

    Parameters:
        stochastic_curves: list of (x, y, label) tuples
        deterministic_curves: list of (x, y, label) tuples
        filename: string, file path to save the figure
    """
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))

    ax1.set_xlabel('Timestep')
    ax1.set_ylabel('Episode Return')
    for x, y, label in stochastic_curves:
        ax1.plot(x, y, label=label)
    ax1.legend()

    ax2.set_xlabel('Timestep')
    ax2.set_ylabel('Episode Return')
    for x, y, label in deterministic_curves:
        ax2.plot(x, y, label=label)
    ax2.legend()

    plt.tight_layout()
    fig.savefig(filename, dpi=300)
    plt.close(fig)

def compare_runtimes(n_timesteps, epsilon, n_reps):
    """
    Measures runtimes (in seconds) for Q-Learning, DynaQ (n=5), and Prioritized Sweeping (n=5)
    under both stochastic and deterministic wind settings. Displays results in a pivoted table
    with one row per agent and columns for deterministic and stochastic settings.
    
    Returns:
        pd.DataFrame: pivoted table with runtimes.
    """
    agents = [
        ("Q-Learning", 'dyna', 0),
        ("DynaQ (n=5)", 'dyna', 5),
        ("PS (n=5)", 'prio', 5)
    ]
    raw_results = []

    for label, agent_type, n_updates in agents:
        for setting, wind in [('Stochastic', 0.9), ('Deterministic', 1.0)]:
            start = time.time()
            run_repetitions(
                n_timesteps=n_timesteps,
                epsilon=epsilon,
                n_planning_updates=n_updates,
                wind_proportion=wind,
                n_reps=n_reps,
                agent=agent_type
            )
            end = time.time()
            duration = round(end - start, 2)
            raw_results.append({
                'Agent': label,
                'Setting': setting,
                'Runtime (s)': duration
            })

    # Convert and pivot table
    df_raw = pd.DataFrame(raw_results)
    df_pivot = df_raw.pivot(index='Agent', columns='Setting', values='Runtime (s)').reset_index()
    df_pivot = df_pivot[['Agent', 'Deterministic', 'Stochastic']]  # Ensure column order

    print("\nRuntime Comparison (20 repetitions):")
    print(tabulate(df_pivot, headers='keys', tablefmt='pipe', showindex=False))

    # Export as LaTeX table
    with open("runtime_comparison.tex", "w") as f:
        f.write(df_pivot.to_latex(index=False, float_format="%.2f"))

    return df_pivot


def experiment():
    """
    Runs model-based RL experiments on the WindyGridworld using Q-learning, Dyna-Q, 
    and Prioritized Sweeping agents under both stochastic and deterministic wind settings.
    
    For each condition, the function:
    - Runs multiple repetitions of the experiment
    - Evaluates performance at intervals
    - Smooths and plots the learning curves
    - Prints average and final performance metrics
    """
    n_timesteps = 10001
    epsilon = 0.1
    planning_steps = [1, 3, 5]
    wind_settings = {'stochastic': 0.9, 'deterministic': 1.0}

    # --- Q-Learning baseline ---
    q_stochastic, qt_stochastic = run_repetitions(n_timesteps, epsilon, 0, wind_proportion=0.9)
    q_deterministic, qt_deterministic = run_repetitions(n_timesteps, epsilon, 0, wind_proportion=1.0)

    # --- Dyna Agents ---
    dyna_results_stochastic = [(qt_stochastic, smooth(q_stochastic, 3), 'Q-Learning')]
    dyna_results_deterministic = [(qt_deterministic, smooth(q_deterministic, 3), 'Q-Learning')]
    dyna_rewards_stochastic = [q_stochastic]
    dyna_rewards_deterministic = [q_deterministic]

    for n in planning_steps:
        m_stoch, t_stoch = run_repetitions(n_timesteps, epsilon, n, wind_proportion=0.9)
        m_deter, t_deter = run_repetitions(n_timesteps, epsilon, n, wind_proportion=1.0)
        dyna_results_stochastic.append((t_stoch, smooth(m_stoch, 3), f'Dyna (K={n})'))
        dyna_results_deterministic.append((t_deter, smooth(m_deter, 3), f'Dyna (K={n})'))
        dyna_rewards_stochastic.append(m_stoch)
        dyna_rewards_deterministic.append(m_deter)

    plot_learning_curves(dyna_results_stochastic, dyna_results_deterministic, filename='dyna_plot.png')
    summarize_mbrl_performance(dyna_rewards_stochastic, ["Q-Learning"] + [f"Dyna (K={n})" for n in planning_steps])
    summarize_mbrl_performance(dyna_rewards_deterministic, ["Q-Learning"] + [f"Dyna (K={n})" for n in planning_steps])

    # --- Prioritized Sweeping Agents ---
    prio_results_stochastic = [(qt_stochastic, smooth(q_stochastic, 3), 'Q-Learning')]
    prio_results_deterministic = [(qt_deterministic, smooth(q_deterministic, 3), 'Q-Learning')]
    prio_rewards_stochastic = [q_stochastic]
    prio_rewards_deterministic = [q_deterministic]

    for n in planning_steps:
        m_stoch, t_stoch = run_repetitions(n_timesteps, epsilon, n, wind_proportion=0.9, agent='prio')
        m_deter, t_deter = run_repetitions(n_timesteps, epsilon, n, wind_proportion=1.0, agent='prio')
        prio_results_stochastic.append((t_stoch, smooth(m_stoch, 3), f'PS (K={n})'))
        prio_results_deterministic.append((t_deter, smooth(m_deter, 3), f'PS (K={n})'))
        prio_rewards_stochastic.append(m_stoch)
        prio_rewards_deterministic.append(m_deter)

    plot_learning_curves(prio_results_stochastic, prio_results_deterministic, filename='prio_plot.png')
    summarize_mbrl_performance(prio_rewards_stochastic, ["Q-Learning"] + [f"PS (K={n})" for n in planning_steps])
    summarize_mbrl_performance(prio_rewards_deterministic, ["Q-Learning"] + [f"PS (K={n})" for n in planning_steps])

    # --- Comparison Plot ---
    comparison_curves_stochastic = [
        (qt_stochastic, smooth(q_stochastic, 3), 'Q-Learning'),
        (dyna_results_stochastic[-1][0], dyna_results_stochastic[-1][1], 'Dyna (K=5)'),
        (prio_results_stochastic[-1][0], prio_results_stochastic[-1][1], 'PS (K=5)')
    ]

    comparison_curves_deterministic = [
        (qt_deterministic, smooth(q_deterministic, 3), 'Q-Learning'),
        (dyna_results_deterministic[-1][0], dyna_results_deterministic[-1][1], 'Dyna (K=5)'),
        (prio_results_deterministic[-1][0], prio_results_deterministic[-1][1], 'PS (K=5)')
    ]

    plot_learning_curves(
        comparison_curves_stochastic,
        comparison_curves_deterministic,
        filename='comparison_plots.png'
    )

    compare_runtimes(n_timesteps=n_timesteps, epsilon=epsilon, n_reps=20)

def run_repetitions(n_timesteps, epsilon, n_planning_updates, eval_interval=250, wind_proportion=0.9, n_reps=20, agent='dyna', seed=3000):
    mean_mean_rewards = []

    for i in range(n_reps):
        s = seed + i
        np.random.seed(s)

        mean_rewards = []
        env = WindyGridworld(wind_proportion=wind_proportion)

        if agent == 'dyna':
            agent_instance = DynaAgent(env.n_states, env.n_actions, learning_rate=0.2, gamma=1.0, seed=s)
        elif agent == 'prio':
            agent_instance = PrioritizedSweepingAgent(env.n_states, env.n_actions, learning_rate=0.2, gamma=1.0, seed=s)

        state = env.reset()
        timesteps_evaluated = []

        for t in range(1, n_timesteps):
            action = agent_instance.select_action(state, epsilon)
            next_state, reward, done = env.step(action)
            agent_instance.update(state, action, reward, done, next_state, n_planning_updates)

            if t % eval_interval == 0:
                mean_rewards.append(agent_instance.evaluate(env))
                timesteps_evaluated.append(t)

            state = env.reset() if done else next_state

        mean_mean_rewards.append(mean_rewards)

    mean_mean_mean_rewards = np.mean(mean_mean_rewards, axis=0)
    return mean_mean_mean_rewards, timesteps_evaluated

if __name__ == '__main__':
    experiment()
    


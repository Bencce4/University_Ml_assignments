#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Model-based Reinforcement Learning policies
Practical for course 'Reinforcement Learning',
Bachelor AI, Leiden University, The Netherlands
By Thomas Moerland
"""
import numpy as np
from queue import PriorityQueue
from MBRLEnvironment import WindyGridworld

class DynaAgent:

    def __init__(self, n_states, n_actions, learning_rate, gamma, seed=4000):
        self.n_states = n_states
        self.n_actions = n_actions
        self.learning_rate = learning_rate
        self.gamma = gamma
        self.rng = np.random.default_rng(seed)
        self.Q_sa = np.zeros((self.n_states, self.n_actions))
        self.transition_counts = np.zeros((self.n_states, self.n_actions, self.n_states))
        self.reward_sums = np.zeros((self.n_states, self.n_actions, self.n_states))

        self.model_transition_function = np.zeros((self.n_states, self.n_actions, self.n_states))
        self.model_reward_function = np.zeros((self.n_states, self.n_actions, self.n_states))
        
    def select_action(self, state, epsilon):
        if self.rng.random() < epsilon:
            return self.rng.integers(self.n_actions)
        else:
            max_value = np.max(self.Q_sa[state])
            best_actions = np.flatnonzero(self.Q_sa[state] == max_value)
            return self.rng.choice(best_actions)
    
    def update_model(self, state, action, reward, next_state):
        self.transition_counts[state, action, next_state] += 1
        self.reward_sums[state, action, next_state] += reward

        self.model_transition_function[state, action] = (
            self.transition_counts[state, action] / self.transition_counts[state, action].sum()
        )

        self.model_reward_function[state, action, next_state] = (
            self.reward_sums[state, action, next_state] / self.transition_counts[state, action, next_state]
        )

    def update(self, state, action, reward, done, next_state, n_planning_updates):
        self.Q_sa[state, action] += self.learning_rate * (
            reward + self.gamma * np.max(self.Q_sa[next_state]) - self.Q_sa[state, action]
        )

        self.update_model(state, action, reward, next_state)

        visited_mask = self.transition_counts.sum(axis=2) > 0
        visited_states = np.where(visited_mask.any(axis=1))[0]

        for _ in range(n_planning_updates):
            sampled_state = self.rng.choice(visited_states)
            valid_actions = np.where(visited_mask[sampled_state])[0]
            sampled_action = self.rng.choice(valid_actions)

            sampled_next_state = self.rng.choice(
                self.n_states, p=self.model_transition_function[sampled_state, sampled_action]
            )
            sampled_reward = self.model_reward_function[sampled_state, sampled_action, sampled_next_state]

            self.Q_sa[sampled_state, sampled_action] += self.learning_rate * (
                sampled_reward + self.gamma * np.max(self.Q_sa[sampled_next_state]) - self.Q_sa[sampled_state, sampled_action]
            )

    def evaluate(self, eval_env, n_eval_episodes=30, max_episode_length=100):
        returns = []
        for _ in range(n_eval_episodes):
            state = eval_env.reset()
            total_reward = 0
            for _ in range(max_episode_length):
                action = np.argmax(self.Q_sa[state])
                next_state, reward, done = eval_env.step(action)
                total_reward += reward
                if done:
                    break
                state = next_state
            returns.append(total_reward)
        return np.mean(returns)

class PrioritizedSweepingAgent:

    def __init__(self, n_states, n_actions, learning_rate, gamma, priority_cutoff=0.01, seed=4000):
        self.n_states = n_states
        self.n_actions = n_actions
        self.learning_rate = learning_rate
        self.gamma = gamma
        self.priority_cutoff = priority_cutoff
        self.queue = PriorityQueue()
        self.rng = np.random.default_rng(seed)
        self.Q_sa = np.ones((self.n_states, self.n_actions))
        self.transition_counts = np.zeros((self.n_states, self.n_actions, self.n_states))
        self.reward_sums = np.zeros((self.n_states, self.n_actions, self.n_states))

        self.model_transition_function = np.zeros((self.n_states, self.n_actions, self.n_states))
        self.model_reward_function = np.zeros((self.n_states, self.n_actions, self.n_states))
        
    def select_action(self, state, epsilon):
        if self.rng.random() < epsilon:
            return self.rng.integers(self.n_actions)
        else:
            max_value = np.max(self.Q_sa[state])
            best_actions = np.flatnonzero(self.Q_sa[state] == max_value)
            return self.rng.choice(best_actions)
    
    def update_model(self, state, action, reward, next_state):
        self.transition_counts[state, action, next_state] += 1
        self.reward_sums[state, action, next_state] += reward

        self.model_transition_function[state, action] = (
            self.transition_counts[state, action] / self.transition_counts[state, action].sum()
        )

        self.model_reward_function[state, action, next_state] = (
            self.reward_sums[state, action, next_state] / self.transition_counts[state, action, next_state]
        )
        
    def update(self, state, action, reward, done, next_state, n_planning_updates): 
        priority = np.abs(reward + self.gamma * np.max(self.Q_sa[next_state]) - self.Q_sa[state, action])
        if priority > self.priority_cutoff:
            self.queue.put((-priority, (state, action)))

        self.update_model(state, action, reward, next_state)

        for _ in range(n_planning_updates):
            if self.queue.empty():
                break
            _, (sampled_state, sampled_action) = self.queue.get()

            sampled_next_state = self.rng.choice(self.n_states, p=self.model_transition_function[sampled_state, sampled_action])
            sampled_reward = self.model_reward_function[sampled_state, sampled_action, sampled_next_state]

            self.Q_sa[sampled_state, sampled_action] += self.learning_rate * (
                sampled_reward + self.gamma * np.max(self.Q_sa[sampled_next_state]) - self.Q_sa[sampled_state, sampled_action]
            )

            for pred_state, pred_action in np.argwhere(self.transition_counts[:, :, sampled_state] > 0):
                pred_reward = self.model_reward_function[pred_state, pred_action, sampled_state]
                pred_priority = np.abs(pred_reward + self.gamma * np.max(self.Q_sa[sampled_state]) - self.Q_sa[pred_state, pred_action])
                if pred_priority > self.priority_cutoff:
                    self.queue.put((-pred_priority, (pred_state, pred_action)))
        self.queue = PriorityQueue()

    def evaluate(self, eval_env, n_eval_episodes=30, max_episode_length=100):
        returns = []
        for _ in range(n_eval_episodes):
            state = eval_env.reset()
            total_reward = 0
            for _ in range(max_episode_length):
                action = np.argmax(self.Q_sa[state])
                next_state, reward, done = eval_env.step(action)
                total_reward += reward
                if done:
                    break
                state = next_state
            returns.append(total_reward)
        return np.mean(returns)

def test():
    n_timesteps = 10001
    gamma = 1

    policy = 'ps'
    epsilon = 0.1
    learning_rate = 0.2
    n_planning_updates = 5

    plot = True
    plot_optimal_policy = True
    step_pause = 0.0001
    
    np.random.seed(4000)
    env = WindyGridworld()
    if policy == 'dyna':
        agent = DynaAgent(env.n_states, env.n_actions, learning_rate, gamma)
    elif policy == 'ps':    
        agent = PrioritizedSweepingAgent(env.n_states, env.n_actions, learning_rate, gamma)
    else:
        raise KeyError('Policy {} not implemented'.format(policy))
    
    state = env.reset()  
    continuous_mode = False
    goal_count = 0

    for t in range(n_timesteps):      
        action = agent.select_action(state, epsilon)
        next_state, reward, done = env.step(action) 
        agent.update(state, action, reward, done, next_state, n_planning_updates)
        
        if plot:
            env.render(Q_sa=agent.Q_sa, plot_optimal_policy=plot_optimal_policy, step_pause=step_pause)
            
        if not continuous_mode:
            key_input = input("Press 'Enter' to execute next step, press 'c' to run full algorithm")
            continuous_mode = True if key_input == 'c' else False

        if done:
            goal_count += 1
            state = env.reset()
            print(f'Found Goal {goal_count} timestep {t}')
        else:
            state = next_state

if __name__ == '__main__':
    test()
